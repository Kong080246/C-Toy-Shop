﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Project
{
    public partial class Form5 : Form
    {
        private MySqlConnection databaseConnection()
        {
            //Connection String สำหรับใช้เชื่อมต่อฐานข้อมูล โดยระบุชื่อ Host,Port,Username,Password และชื่อ database
            string connectionString = "host=localhost;user=root;password=;database=project";

            //สร้างตัวแปลชื่อ conn เพื่อใช้เก็บการเชื่อมต่อฐานข้อมูล โดยใส่ค่า conncetionstring เข้าไป
            MySqlConnection conn = new MySqlConnection(connectionString);

            //ส่งค่าการเชื่อมต่อฐานข้อมูลกลับไปยังที่ที่เรียกใช้งาน Method
            return conn;
        }
        private void showEquipment()
        {
            MySqlConnection conn = databaseConnection();
            DataSet ds = new DataSet();
            conn.Open();

            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT * FROM customer WHERE user ='{Form1.globaluser}'AND password ='{Form1.globalpassword}'";

            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);

            conn.Close();

            dataEquipment.DataSource = ds.Tables[0].DefaultView;

        }
        public Form5()
        {
            InitializeComponent();
            showEquipment();
        }

        private void dataEquipment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dataEquipment.CurrentRow.Selected = true;
            textBox3.Text = dataEquipment.Rows[e.RowIndex].Cells["name"].FormattedValue.ToString();
            textBox4.Text = dataEquipment.Rows[e.RowIndex].Cells["address"].FormattedValue.ToString();
            textBox5.Text = dataEquipment.Rows[e.RowIndex].Cells["tel"].FormattedValue.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int selectedRow = dataEquipment.CurrentCell.RowIndex;
            int editId = Convert.ToInt32(dataEquipment.Rows[selectedRow].Cells["id"].Value);
            MySqlConnection conn = databaseConnection();
            String sql = "UPDATE customer SET name ='" + textBox3.Text + "',address = '" + textBox4.Text + "',tel = '" + textBox5.Text + "'WHERE id = '" + editId + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            conn.Close();
            if (rows > 0)
            {
                MessageBox.Show("แก้ไขข้อมูลสำเร็จ");
                showEquipment();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 gg = new Form2();
            gg.ShowDialog();
        }
    }
}
