﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project
{
    public partial class Form6 : Form
    {
        private MySqlConnection databaseConnection()
        {
            //Connection String สำหรับใช้เชื่อมต่อฐานข้อมูล โดยระบุชื่อ Host,Port,Username,Password และชื่อ database
            string connectionString = "host=localhost;user=root;password=;database=project";

            //สร้างตัวแปลชื่อ conn เพื่อใช้เก็บการเชื่อมต่อฐานข้อมูล โดยใส่ค่า conncetionstring เข้าไป
            MySqlConnection conn = new MySqlConnection(connectionString);

            //ส่งค่าการเชื่อมต่อฐานข้อมูลกลับไปยังที่ที่เรียกใช้งาน Method
            return conn;
        }
        private void showEquipment(string sql)
        {
            MySqlConnection conn = databaseConnection();
            DataSet ds = new DataSet();
            conn.Open();

            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = sql;

            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);

            conn.Close();

            dataEquipment.DataSource = ds.Tables[0].DefaultView;

            MySqlConnection conn__ = new MySqlConnection("host=localhost;user=root;password=;database=project");
            string sql_ = sql;
            MySqlCommand cmd__ = new MySqlCommand(sql_, conn__);
            conn__.Open();
            MySqlDataReader reader = cmd__.ExecuteReader();
            int sum = 0;
            while (reader.Read())
            {
                sum += reader.GetInt32("price");
            }
            textBox2.Text = sum.ToString();
        }
        private void showdatabase()
        {
            MySqlConnection conn_ = databaseConnection();
            DataSet ds_ = new DataSet();
            conn_.Open();

            MySqlCommand cmd_;

            cmd_ = conn_.CreateCommand();
            cmd_.CommandText = "SELECT * FROM history";

            MySqlDataAdapter adapter_ = new MySqlDataAdapter(cmd_);
            adapter_.Fill(ds_);

            conn_.Close();

            dataEquipment.DataSource = ds_.Tables[0].DefaultView;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You Logout Form Admin");
            this.Hide();
            Form1 tt = new Form1();
            tt.ShowDialog();
        }

        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            showEquipment("SELECT * FROM history");
            showdatabase();
            searchData("");
        }

        MySqlConnection connection = new MySqlConnection("datasource=localhost;user=root;password=;database=project");

        public void searchData(string valueToFind)
        {
            string searchQuery = "SELECT * FROM history WHERE CONCAT(lastuser,item,price,datena) LIKE '%"+valueToFind+"%'";
            MySqlDataAdapter adapter3 = new MySqlDataAdapter(searchQuery, connection);
            DataTable table = new DataTable();
            adapter3.Fill(table);
            dataEquipment.DataSource = table;

        }

        private void dataEquiment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                dataEquipment.CurrentRow.Selected = true;
                r = dataEquipment.Rows[e.RowIndex].Cells["lastuser"].FormattedValue.ToString();
                t = dataEquipment.Rows[e.RowIndex].Cells["item"].FormattedValue.ToString();
                y = dataEquipment.Rows[e.RowIndex].Cells["price"].FormattedValue.ToString();
                p = Convert.ToInt32(dataEquipment.Rows[e.RowIndex].Cells["id"].FormattedValue.ToString());
            }
            catch
            {

            }
        }
        string r, t, y;

        private void Form6_TextChanged(object sender, EventArgs e)
        {
            searchData(textBox1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 tt = new Form7();
            tt.ShowDialog();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Text = "";
            int x = 0;
            if (comboBox2.Text == "01" || comboBox2.Text == "03" || comboBox2.Text == "05" ||
                comboBox2.Text == "07" || comboBox2.Text == "08" || comboBox2.Text == "10" ||
                comboBox2.Text == "12")
            {
                x = 31;
            }
            else if (comboBox2.Text == "04" || comboBox2.Text == "06" || comboBox2.Text == "09" ||
                comboBox2.Text == "11")
            {
                x = 30;
            }
            else if (comboBox2.Text == "02")
            {
                x = 28;
            }
            comboBox1.Items.Add("");
            for (int i = 1; i <= x; i++)
            {
                comboBox1.Items.Add(i.ToString());
            }
            chooseday();
        }
        string combo;
        private void chooseday()
        {
            if (comboBox3.Text != "")
            {
                combo = "%" + comboBox3.Text + "%";
            }
            if (comboBox2.Text != "")
            {
                combo = "%" + comboBox2.Text + "/" + comboBox3.Text + "%";
            }
            if (comboBox1.Text != "")
            {
                combo = "%" + comboBox1.Text + "/" + comboBox2.Text + "/" + comboBox3.Text + "%";
            }

            showEquipment("SELECT * FROM history WHERE datena LIKE '" + combo + "' ");
            
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            chooseday();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            chooseday();
        }


        int p;

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("ยืนยันการทำรายการหรือไม่?", "แจ้งตือน", MessageBoxButtons.YesNo);
            switch (dr)
            {
                case DialogResult.Yes:

                    string sql = "DELETE FROM history WHERE lastuser= '" + r + "' and item	='" + t + "' and price ='" + y + "' and id = '" + p + "'";
                    MySqlConnection con = new MySqlConnection("host=localhost;user=root;password=;database=project");
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    con.Open();
                    int rows = cmd.ExecuteNonQuery();
                    con.Close();

                    showdatabase();
                    if (rows > 0)
                    {
                        MessageBox.Show("ลบข้อมูลสำเร็จ");
                        showEquipment("SELECT * FROM history");
                    }
                    break;
                case DialogResult.No:
                    break;
            }
        }
    }
}
